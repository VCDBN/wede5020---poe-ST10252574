//animates the text and positions its starting value and length of text //
function animateText(textArea) {
    let text = textArea.value;
    let to = text.length,
      from = 0;

      // animates the duration and timing of the text that will bounce and appear in the textbox //
    animate({
      duration: 5000,
      timing: bounce,
      draw: function(progress) {
        let result = (to - from) * progress + from;
        textArea.value = text.slice(0, Math.ceil(result))
      }
    });
  }

// animates the bouncing and appaerance of the text in the text box //
  function bounce(timeFraction) {
    for (let a = 0, b = 1; 1; a += b, b /= 2) {
      if (timeFraction >= (7 - 4 * a) / 11) {
        return -Math.pow((11 - 6 * a - 11 * timeFraction) / 4, 2) + Math.pow(b, 2)
      }
    }
  }