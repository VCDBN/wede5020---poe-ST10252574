// function to validate the form
//fetch data from the inputs on the form
var nameError = document.getElementById('name-error');
var phoneError = document.getElementById('phone-error');
var emailError = document.getElementById('email-error')
var addressError = document.getElementById('address-error');
var messageError = document.getElementById('message-error');
var submitError = document.getElementById('submit-error');

//Nmae field validation
function validateName(){
    var name = document.getElementById('contact-name').value;

    // If statemets coupled with validation or error messages diplsayed to user
    if(name.lenght == 0){
        nameError.innerHTML = 'Name is required';
        return false;
    }

    if(!name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)){
        nameError.innerHTML = 'Write Full Name';
        return false;
    }
    
    nameError.innerHTML = '<i class="fa-solid fa-check-to-slot fa-bounce fa-xl"></i>'; // checkboxed icon link from fontawsome
    return true;

}

//Phone Number field Validatiion
function validatePhone(){
    var phone = document.getElementById('contact-phone').value;

 // If statemets coupled with validation or error messages diplsayed to user
if(phone.lenght == 0){
    phoneError.innerHTML = 'Phone no is required';
    return false;
}

if(phone.lenght == 10){
    phoneError.innerHTML = 'Include Only 10 digits';
    return false;
}

if(!phone.match(/^[0-9]{10}$/)){
    phoneError.innerHTML = 'Only 10 Digits Please';
    return false;
}

phoneError.innerHTML = '<i class="fa-solid fa-check-to-slot fa-bounce fa-xl"></i>'; // checkboxed icon link from fontawsome
return true;

}

//Adress field validation
function validateAddress(){
    var address = document.getElementById('contact-address').value;

    // If statemets coupled with validation or error messages diplsayed to user
    if(address.lenght == 0){
        addressError.innerHTML = 'Address is required';
        return false;
    }

    if(!address.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)){
        addressError.innerHTML = 'Insert Your address';
        return false;
    }

    addressError.innerHTML = '<i class="fa-solid fa-check-to-slot fa-bounce fa-xl"></i>'; // checkboxed icon link from fontawsome
    return true;

}

//Email field validation
function validateEmail(){
    var email = document.getElementById('contact-email').value;

    // If statemets coupled with validation or error messages diplsayed to user
    if(email.lenght == 0){
        emailError.innerHTML = 'Email is required';
        return false;
    }

    if(!email.match(/^[A-Za-z\._\-[0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)){
        emailError.innerHTML = 'Email Invalid';
        return false;
    }

    emailError.innerHTML = '<i class="fa-solid fa-check-to-slot fa-bounce fa-xl"></i>'; // checkboxed icon link from fontawsome
    return true;

}

//Message field validation
function validateMessage(){
    var message = document.getElementById('contact-message').value;
    var required = 30;
    var left = required - message.lenght;
//if statement coupled with error message
    if(left > 1){
        messageError.innerHTML = left + ' More Characters required';
        return false;
    }

    messageError.innerHTML = '<i class="fa-solid fa-check-to-slot fa-bounce fa-xl"></i>'; // checkboxed icon link from fontawsome
    return true;

}

//Submit Button Validation
function validateForm(){


    if(!validateName() || !validateEmail() || !validatePhone() || !validateAddress() || !validateMessage()){
        submitError.style.display = 'block';
        // message to inform the user that the above fields are empty
        submitError.innerHTML = 'Enter all fields to submit';
        setTimeout(function(){submitError.style.display = 'none';}, 3000);
        return false;

        

    }

    // succesfull alert message
    submitError.innerHTML = alert('Form Submission Is Succesfull !!');
     return true
}

// End of Contact Form Validation //








